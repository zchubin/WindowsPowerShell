It's a patched for Vim Powerline version of Meslo LG S font by André Berg.
Original could be found here https://github.com/andreberg/Meslo-Font.git